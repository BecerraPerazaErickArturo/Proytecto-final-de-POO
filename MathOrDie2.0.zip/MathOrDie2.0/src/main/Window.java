package main;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.image.BufferStrategy;

import javax.swing.JFrame;

import graphics.Assets;
import input.KeyBoard;
import states.GameState;

public class Window extends JFrame implements Runnable {

	public static final int WIDTH = 800, HEIGHT = 600;
	private Canvas canvas;
	private Thread thread;
	private boolean running = false;

	private BufferStrategy bs;
	private Graphics g;

	private final int FPS = 60;
	private double TARGET_TIME = 1000000000 / FPS; // lo mediremos en milisegundos por presicion
	private double delta = 0;
	private int AVERAGE_FPS = FPS;

	private GameState gameState;
	private KeyBoard keyBoard;

	public Window() {

		setTitle("Math or Die");
		setSize(WIDTH, HEIGHT);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);
		setLocationRelativeTo(null);
		setVisible(true);

		canvas = new Canvas();
		keyBoard = new KeyBoard();

		canvas.setPreferredSize(new Dimension(WIDTH, HEIGHT));
		canvas.setMaximumSize(new Dimension(WIDTH, HEIGHT));
		canvas.setMinimumSize(new Dimension(WIDTH, HEIGHT));
		canvas.setFocusable(true);

		add(canvas);
		canvas.addKeyListener(keyBoard);
	}

	public static void main(String[] args) {

		new Window().start();

	}

	private void update() {

		keyBoard.update();
		gameState.update();

	}

	private void draw() {
		bs = canvas.getBufferStrategy();

		if (bs == null) {
			canvas.createBufferStrategy(3);
			return;
		}

		g = bs.getDrawGraphics();

		// ---

		g.setColor(Color.BLACK);
		g.fillRect(0, 0, WIDTH, HEIGHT);

		gameState.draw(g);

		g.drawString("" + AVERAGE_FPS, 10, 10);

		// ---
		g.dispose();
		bs.show();

		// createBufferStrategy(1); // para que no parpadee el cuadro
	}

	private void init() {

		Assets.init();
		gameState = new GameState();
	}

	@Override
	public void run() {

		long now = 0; // registro de tiempo que pasa
		long last_Time = System.nanoTime();
		int frames = 0;
		long time = 0;

		init();

		while (running) {

			now = System.nanoTime();
			delta += (now - last_Time) / TARGET_TIME;
			time += (now - last_Time);
			last_Time = now;

			if (delta >= 1) {
				update();
				draw();
				delta--;
				frames++;
			}
			if (time >= 1000000000) {// ya habr� pasado 1 seg
				AVERAGE_FPS = frames;
				frames = 0;
				time = 0;
			}

		}

		stop();
	}

	private void start() {
		thread = new Thread(this);
		thread.start();
		running = true;
	}

	private void stop() {
		try {
			thread.join();
			running = false;
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}
