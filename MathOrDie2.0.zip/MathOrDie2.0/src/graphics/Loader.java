package graphics;

import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Loader {
	// los metodos de aqui tienen que ser static

	public static BufferedImage ImageLoader(String path) {

		try {
			return ImageIO.read(Loader.class.getResource(path));
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null; // en caso de que no se cargue la imagen
	}

}
