package gameObjects;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

import math.Vector2D;

public abstract class GameObject {
	protected BufferedImage texture; // solo accedido por metodos de la misma clase
	protected Vector2D posicion;

	public GameObject(Vector2D posicion, BufferedImage texture) {

		this.posicion = posicion;
		this.texture = texture;
	}

	public abstract void update();

	public abstract void draw(Graphics g);

	public Vector2D getPosicion() {
		return posicion;
	}

	public void setPosicion(Vector2D posicion) {
		this.posicion = posicion;
	}

}
